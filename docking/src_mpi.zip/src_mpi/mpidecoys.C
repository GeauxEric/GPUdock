#include <math.h>
#include <algorithm>
#include <mpi.h>
#include "mpidecoys.h"
#include "../lib/debug.h"

#define     MPI		1
#define     TUNE	0

const int SIZE = 70000;

//float static mcc_matrix[SIZE][SIZE];

using namespace std;

void Decoy(Complex * d_complex, std::string iname, std::string oname)
{
	ifstream infile;
	fstream outfile;

	vector < string > data;	// contains the input file content
	vector < float >mcc;

	string inputline;
	int number_of_lines = 0;
	infile.open(iname.c_str());
	if (infile.is_open()) {
		while (!infile.eof()) {
			getline(infile, inputline);
			data.push_back(inputline);
			number_of_lines++;
		}
	}
	// DEBUG_2_("number_of_lines: ", number_of_lines);
	outfile.open(oname.c_str());
	// int line=0;
	int atoms, newpens, newlens;
	infile.clear();
	infile.seekg(0, ios::beg);
	atoms = d_complex->getLigandAtomsTotal();

	int total_confs = ((number_of_lines - 1) / (atoms + 3));

	int mccMatrix_size = 0;
	for (int i = total_confs; i > 0; i--)
		mccMatrix_size += i;

	float *mccMatrix = new float[mccMatrix_size];

	// DEBUG_2_("total_confs: ", total_confs);
	double newcoords[MAXLIG][3];

	int conf = 0;
	int n1;			// index for fetching new native parameters

#if MPI
	int rank;
	int size;
	MPI_Init(NULL, NULL);

	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif

	// if odd number, last row computed individually
	if (total_confs % 2 == 1) {

		if (rank == 0) {	// compute the last conf
			// DEBUG_2_("this is rank 0 dealing with last conf: ", total_confs-1);

			conf = total_confs - 1;

			// cout << conf << endl;
			// DEBUG_4_("rank: ", rank);
			// DEBUG_4_("heads", conf);
			n1 = ((atoms + 3) * conf);

			newpens = atoi((data[n1]).c_str());
			newlens = atoi((data[n1 + 1]).c_str());

#if TUNE
			d_complex->setProteinEnsembleCurrent(newpens);
			d_complex->setLigandEnsembleCurrent(newlens);
#endif

			for (int j = n1 + 2, k = 0; k < atoms; j++, k++) {
				stringstream vec1_entry((data[j]).c_str());
				vec1_entry >> newcoords[k][0] >> newcoords[k][1] >> newcoords[k][2];
			}

#if TUNE
			d_complex->setConfCoords(newcoords);	// set lig conf coords
			d_complex->clearContactMatrix();
			d_complex->createContactMatrix();
#endif

			int pens_p;
			int lens_p;
			Complex complex_p = *d_complex;
			double coords_p[MAXLIG][3];

			int conf2_p;
			int n;	//used for vector entries

			for (conf2_p = conf; conf2_p < total_confs; conf2_p++) {

#if 0
				DEBUG_3_("rank:", rank);
				DEBUG_3_("cycle: ", cycle);
				DEBUG_3_("conf2_p: ", conf2_p);
#endif

				if (conf2_p < total_confs) {

					//Calculate mcc for each conformation relative the the current "native"

					n = ((atoms + 3) * conf2_p);

					pens_p = atoi((data[n]).c_str());
					lens_p = atoi((data[n + 1]).c_str());

#if TUNE
					complex_p.setProteinEnsembleCurrent(pens_p);
					complex_p.setLigandEnsembleCurrent(lens_p);
#endif

					for (int j = n + 2, k = 0; k < atoms; j++, k++) {
						stringstream vec_entry((data[j]).c_str());
						vec_entry >> coords_p[k][0] >> coords_p[k][1] >> coords_p[k][2];
					}

#if TUNE
					complex_p.setConfCoords(coords_p);
					complex_p.calculateEnergy();
#endif

					int mcc_index = 0;

					if (conf == 0) {
						mcc_index = conf2_p;	// does rank start at 0 or 1?
					} else {
						for (int i = 1; i <= conf; i++) {
							mcc_index += total_confs - (i - 1);
						}
						mcc_index += conf2_p - conf;
					}

					// cout <<  rank << conf << conf2_p << " mcc_index: " << mcc_index <<" cmcc " << complex_p.getEnergy(1) << endl;

#if 0
					cout << mcc_index << "	" << complex_p.getEnergy(1) << endl;
					DEBUG_4_("conf: ", conf);
					DEBUG_4_("mcc_index: ", mcc_index);
					DEBUG_4_("cmcc: ", complex_p.getEnergy(1));
					DEBUG_4_("rank: ", rank);
					DEBUG_4_("conf2_p: ", conf2_p);
#endif

					mccMatrix[mcc_index] = complex_p.getEnergy(1);
				}
			}

			// compute_a_row (row, mcc);
			// compute_a_row (total_confs - row - 1, mcc);

		}

		total_confs--;
	}
	//==========================================================================
	// dispatch the work and compute
	int half_total = total_confs / 2;
	int half_rows_per_process = (int)ceil((float)half_total / size);
	int begin_row = half_rows_per_process * rank;
	int end_row = min(begin_row + half_rows_per_process - 1, half_total - 1);

#if TUNE
	DEBUG_2_("half_rows_per_process: ", half_rows_per_process);
	DEBUG_3_("half_rows_per_process: ", half_rows_per_process);
	DEBUG_3_("rank: ", rank);
	DEBUG_3_("begin_row: ", begin_row);
	DEBUG_3_("end_row: ", end_row);
	DEBUG_3_("tail_begin: ", total_confs - 1 - end_row);
	DEBUG_3_("tail_end: ", total_confs - 1 - begin_row);
#endif

	//==========================================================================
	//compute the heads of the upper triangular matrix
	for (conf = begin_row; conf <= end_row; ++conf) {

		// cout << conf << endl;
		// DEBUG_4_("rank: ", rank);
		// DEBUG_4_("heads", conf);
		n1 = ((atoms + 3) * conf);

		newpens = atoi((data[n1]).c_str());
		newlens = atoi((data[n1 + 1]).c_str());

#if TUNE
		d_complex->setProteinEnsembleCurrent(newpens);
		d_complex->setLigandEnsembleCurrent(newlens);
#endif

		for (int j = n1 + 2, k = 0; k < atoms; j++, k++) {
			stringstream vec1_entry((data[j]).c_str());
			vec1_entry >> newcoords[k][0] >> newcoords[k][1] >> newcoords[k][2];
		}

#if TUNE
		d_complex->setConfCoords(newcoords);	// set lig conf coords
		d_complex->clearContactMatrix();
		d_complex->createContactMatrix();
#endif

		int pens_p;
		int lens_p;
		Complex complex_p = *d_complex;
		double coords_p[MAXLIG][3];

		int conf2_p;
		int n;		//used for vector entries

		for (conf2_p = conf; conf2_p < total_confs; conf2_p++) {

#if 0
			DEBUG_3_("rank:", rank);
			DEBUG_3_("cycle: ", cycle);
			DEBUG_3_("conf2_p: ", conf2_p);
#endif

			if (conf2_p < total_confs) {

				//Calculate mcc for each conformation relative the the current "native"

				n = ((atoms + 3) * conf2_p);

				pens_p = atoi((data[n]).c_str());
				lens_p = atoi((data[n + 1]).c_str());

#if TUNE
				complex_p.setProteinEnsembleCurrent(pens_p);
				complex_p.setLigandEnsembleCurrent(lens_p);
#endif

				for (int j = n + 2, k = 0; k < atoms; j++, k++) {
					stringstream vec_entry((data[j]).c_str());
					vec_entry >> coords_p[k][0] >> coords_p[k][1] >> coords_p[k][2];
				}

#if TUNE
				complex_p.setConfCoords(coords_p);
				complex_p.calculateEnergy();
#endif

				int mcc_index = 0;

				if (conf == 0) {
					mcc_index = conf2_p;	// does rank start at 0 or 1?
				} else {
					for (int i = 1; i <= conf; i++) {
						mcc_index += total_confs - (i - 1);
					}
					mcc_index += conf2_p - conf;
				}

				// cout <<  rank << conf << conf2_p << " mcc_index: " << mcc_index <<" cmcc " << complex_p.getEnergy(1) << endl;

#if 0
				cout << mcc_index << "	" << complex_p.getEnergy(1) << endl;
				DEBUG_4_("conf: ", conf);
				DEBUG_4_("mcc_index: ", mcc_index);
				DEBUG_4_("cmcc: ", complex_p.getEnergy(1));
				DEBUG_4_("rank: ", rank);
				DEBUG_4_("conf2_p: ", conf2_p);
#endif

				mccMatrix[mcc_index] = complex_p.getEnergy(1);
			}
		}

		// compute_a_row (row, mcc);
		// compute_a_row (total_confs - row - 1, mcc);
	}

	//==========================================================================
	// compute the tails of the upper triangular matrix
	for (conf = total_confs - 1 - end_row; conf <= total_confs - 1 - begin_row; ++conf) {

		// cout << conf << endl;
		// DEBUG_4_("rank: ", rank);
		// DEBUG_4_("tails", conf);
		n1 = ((atoms + 3) * conf);

		newpens = atoi((data[n1]).c_str());
		newlens = atoi((data[n1 + 1]).c_str());

#if TUNE
		d_complex->setProteinEnsembleCurrent(newpens);
		d_complex->setLigandEnsembleCurrent(newlens);
#endif

		for (int j = n1 + 2, k = 0; k < atoms; j++, k++) {
			stringstream vec1_entry((data[j]).c_str());
			vec1_entry >> newcoords[k][0] >> newcoords[k][1] >> newcoords[k][2];
		}

#if TUNE
		d_complex->setConfCoords(newcoords);	// set lig conf coords
		d_complex->clearContactMatrix();
		d_complex->createContactMatrix();
#endif

		int pens_p;
		int lens_p;
		Complex complex_p = *d_complex;
		double coords_p[MAXLIG][3];

		int conf2_p;
		int n;		//used for vector entries

		for (conf2_p = conf; conf2_p < total_confs; conf2_p++) {

#if 0
			DEBUG_3_("rank:", rank);
			DEBUG_3_("cycle: ", cycle);
			DEBUG_3_("conf2_p: ", conf2_p);
#endif

			if (conf2_p < total_confs) {

				//Calculate mcc for each conformation relative the the current "native"

				n = ((atoms + 3) * conf2_p);

				pens_p = atoi((data[n]).c_str());
				lens_p = atoi((data[n + 1]).c_str());

#if TUNE
				complex_p.setProteinEnsembleCurrent(pens_p);
				complex_p.setLigandEnsembleCurrent(lens_p);
#endif

				for (int j = n + 2, k = 0; k < atoms; j++, k++) {
					stringstream vec_entry((data[j]).c_str());
					vec_entry >> coords_p[k][0] >> coords_p[k][1] >> coords_p[k][2];
				}

#if TUNE
				complex_p.setConfCoords(coords_p);
				complex_p.calculateEnergy();
#endif

				int mcc_index = 0;

				if (conf == 0) {
					mcc_index = conf2_p;	// does rank start at 0 or 1?
				} else {
					for (int i = 1; i <= conf; i++) {
						mcc_index += total_confs - (i - 1);
					}
					mcc_index += conf2_p - conf;
				}

				// cout <<  rank << conf << conf2_p << " mcc_index: " << mcc_index <<" cmcc " << complex_p.getEnergy(1) << endl;

#if 0
				cout << mcc_index << "	" << complex_p.getEnergy(1) << endl;
				DEBUG_4_("conf: ", conf);
				DEBUG_4_("mcc_index: ", mcc_index);
				DEBUG_4_("cmcc: ", complex_p.getEnergy(1));
				DEBUG_4_("rank: ", rank);
				DEBUG_4_("conf2_p: ", conf2_p);
#endif

				mccMatrix[mcc_index] = complex_p.getEnergy(1);
			}
		}

		// compute_a_row (row, mcc);
		// compute_a_row (total_confs - row - 1, mcc);
	}

#if 0
	//==========================================================================
	// native serial code
	//
	while (conf < total_confs) {

		n1 = ((atoms + 3) * conf);

		newpens = atoi((data[n1]).c_str());
		newlens = atoi((data[n1 + 1]).c_str());

		d_complex->setProteinEnsembleCurrent(newpens);
		d_complex->setLigandEnsembleCurrent(newlens);

		for (int j = n1 + 2, k = 0; k < atoms; j++, k++) {
			stringstream vec1_entry((data[j]).c_str());
			vec1_entry >> newcoords[k][0] >> newcoords[k][1] >> newcoords[k][2];
		}

		d_complex->setConfCoords(newcoords);	// set lig conf coords
		d_complex->clearContactMatrix();
		d_complex->createContactMatrix();

		int pens_p;
		int lens_p;
		Complex complex_p = *d_complex;
		double coords_p[MAXLIG][3];

		int conf2_p;
		int n;		//used for vector entries

		for (conf2_p = conf; conf2_p < total_confs; conf2_p++) {

#if 0
			DEBUG_3_("rank:", rank);
			DEBUG_3_("cycle: ", cycle);
			DEBUG_3_("conf2_p: ", conf2_p);
#endif

			if (conf2_p < total_confs) {

				//Calculate mcc for each conformation relative the the current "native"

				n = ((atoms + 3) * conf2_p);

				pens_p = atoi((data[n]).c_str());
				lens_p = atoi((data[n + 1]).c_str());

				complex_p.setProteinEnsembleCurrent(pens_p);
				complex_p.setLigandEnsembleCurrent(lens_p);

				for (int j = n + 2, k = 0; k < atoms; j++, k++) {
					stringstream vec_entry((data[j]).c_str());
					vec_entry >> coords_p[k][0] >> coords_p[k][1] >> coords_p[k][2];
				}

				complex_p.setConfCoords(coords_p);
				complex_p.calculateEnergy();
				//mcc.push_back(complex_p.getEnergy(1));

				int mcc_index = 0;

				if (conf == 0) {
					mcc_index = conf2_p;	// does rank start at 0 or 1?
				} else {
					for (int i = 1; i <= conf; i++) {
						mcc_index += total_confs - (i - 1);
					}
					mcc_index += conf2_p - conf;
				}

				// cout <<  rank << conf << conf2_p << " mcc_index: " << mcc_index <<" cmcc " << complex_p.getEnergy(1) << endl;

#if 0
				DEBUG_4_("conf: ", conf);
				DEBUG_4_("mcc_index: ", mcc_index);
				DEBUG_4_("cmcc: ", complex_p.getEnergy(1));
				DEBUG_4_("rank: ", rank);
				DEBUG_4_("conf2_p: ", conf2_p);
#endif

				mccMatrix[mcc_index] = complex_p.getEnergy(1);
			}
		}

		conf++;
		// DEBUG_4_("conf", conf);
	}
#endif

#if MPI
	MPI_Finalize();
#endif

	//vector<float>::iterator l1;

#if 0
	//==========================================================================
	// Print the entire matrix from 1D Array

	int l1, l2, l3, l5;
	for (l1 = 0, l2 = 1, l3 = 1; l1 < mccMatrix_size; l1++, l2++) {

		DEBUG_TEST;
		if (l2 == l3) {
			l5 = 0;
			for (int l4 = 0; l4 < (l3 - 1); l4++) {
				if (l4 >= 2)
					l5 += l4 - 1;
				outfile << mccMatrix[(((l4) * total_confs) - (l5)) + (l2 - l4) - 1] << " ";
			}
		}

		outfile << mccMatrix[l1] << " ";
		if (l2 == total_confs) {
			outfile << endl;
			l3++;
			l2 = l3 - 1;
		}
	}
#endif

	delete[]mccMatrix;

	infile.close();
	outfile.close();

}

std::ifstream & GotoLine(std::ifstream & file, int num)
{
	file.seekg(std::ios::beg);
	for (int i = 0; i < num - 1; ++i) {
		file.ignore(std::numeric_limits < std::streamsize >::max(), '\n');
	}
	return file;
}
