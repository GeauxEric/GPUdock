export GPUDOCKSMDAT_FF=../dat/gpudocksm.ff
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/project/michal/apps/gsl/lib/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/packages/openmpi/1.6.2/gcc-4.4.6/lib/

cd ../test/

mpirun -np 16 ../bin/mpi_mcc -p 1a07C.pdb -l 1a07C1.sdf -o mpi_1a07C1-matrixH.sdf -d 1a07C1-decoysH.sdf
