//Header for decoys.C

#include <iostream>
#include <fstream>
#include <string>
#include "complex.h"
#include <limits>


using namespace std;

void Decoy(Complex *, std::string, std::string);

std::ifstream& GotoLine(std::ifstream&, unsigned int );
