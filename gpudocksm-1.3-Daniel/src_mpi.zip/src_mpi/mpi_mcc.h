//Header file for hpcmcc 12-10-12

#ifndef  MPI_MCC_H
#define  MPI_MCC_H


#include<cstring>
#include<fstream>
#include<iostream>
#include<list>

#include "size.h"
#include "complex.h"
#include "mpidecoys.h"


#endif  // MPI_MCC_H
